// First, let's create a simple Lerp function to replace Mathf.Lerp
function lerp(start, end, amount) {
    return start + (end - start) * amount;
}

function getRoughSpeedPenalty(materialIndex, speed, VLA) {
    const speedMultiplier = getRoughSpeedPenaltyForSpeed(materialIndex, speed);
    const vlaMultiplier = getRoughSpeedPenaltyForVLA(materialIndex, VLA);
    return speedMultiplier * vlaMultiplier;
}

function getRoughSpeedPenaltyForVLA(materialIndex, VLA) {
    const offset2 = materialsTable[materialIndex].offset2;
    VLA = Math.min(Math.max(VLA, 0), 45);
    if (vlaIndex < 9) {
        return lerp(
            VLAToSpeed[vlaIndex + offset2],
            VLAToSpeed[vlaIndex + 1 + offset2],
            (VLA % 5) / 5
        );
    } else {
        return VLAToSpeed[9 + offset2];
    }
}

function getRoughSpeedPenaltyForSpeed(materialIndex, speed) {
    const offset = materialsTable[materialIndex].offset1;   
    speed = Math.min(Math.max(speed, 0), 150);
    const speedIndex = Math.floor(speed / 10);
    if (speedIndex < 15) {
        return lerp(
            SpeedToSpeed[speedIndex + offset],
            SpeedToSpeed[speedIndex + 1 + offset],
            (speed % 10) / 10
        );
    } else {
        return SpeedToSpeed[15 + offset];
    }
}

function getRoughSpinPenalty(materialIndex, speed, VLA) {
    const speedMultiplier = getRoughSpinPenaltyForSpeed(materialIndex, speed);
    const vlaMultiplier = getRoughSpinPenaltyForVLA(materialIndex, VLA);
    return speedMultiplier * vlaMultiplier;
}

function getRoughSpinPenaltyForVLA(materialIndex, VLA) {
    const offset2 = materialsTable[materialIndex].offset2;
    VLA = Math.min(Math.max(VLA, 0), 45);
    const vlaIndex = Math.floor(VLA / 5);
    if (vlaIndex < 9) {
        return lerp(
            VLAToSpin[vlaIndex + offset2],
            VLAToSpin[vlaIndex + 1 + offset2],
            (VLA % 5) / 5
        );
    } else {
        return VLAToSpin[9 + offset2];
    }
}

function getRoughSpinPenaltyForSpeed(materialIndex, speed) {
    const offset = materialsTable[materialIndex].offset1;
    speed = Math.min(Math.max(speed, 0), 150);
    const speedIndex = Math.floor(speed / 10);
    if (speedIndex < 15) {
        return lerp(
            SpeedToSpin[speedIndex + offset],
            SpeedToSpin[speedIndex + 1 + offset],
            (speed % 10) / 10
        );
    } else {
        return SpeedToSpin[15 + offset];
    }
}

function getRoughVLAPenalty(materialIndex, speed, VLA) {
   const speedMultiplier = getRoughVLAPenaltyForSpeed(materialIndex, speed);
   const vlaMultiplier = getRoughVLAPenaltyForVLA(materialIndex, VLA);
   return speedMultiplier * vlaMultiplier;  
}

function getRoughVLAPenaltyForVLA(materialIndex, VLA) {
    const offset2 = materialsTable[materialIndex].offset2;
    VLA = Math.min(Math.max(VLA, 0), 45);
    const vlaIndex = Math.floor(VLA / 5);
    if (vlaIndex < 9) {
        return lerp(
            VLAToVLA[vlaIndex + offset2],
            VLAToVLA[vlaIndex + 1 + offset2],
            (VLA % 5) / 5
        );  
   } else {
       return VLAToVLA[9 + offset2];
   }
}

function getRoughVLAPenaltyForSpeed(materialIndex, speed) {
   const offset = materialsTable[materialIndex].offset1;
   speed = Math.min(Math.max(speed, 0), 150);
   const speedIndex = Math.floor(speed / 10);
   if (speedIndex < 15) {
       return lerp(
           SpeedToVLA[speedIndex + offset],
           SpeedToVLA[speedIndex + 1 + offset],
           (speed % 10) / 10
       );
   } else {
       return SpeedToVLA[15 + offset];
   }
}

const materialsTable = {
    12: { name: "TVGsemirough", offset1: 32, offset2: 20 },

    1: { name: "TVGrough", offset1: 0, offset2: 0 },
    6: { name: "TVGearth", offset1: 0, offset2: 0 },
    16: { name: "TVGpinestraw", offset1: 0, offset2: 0 },
    17: { name: "TVGleaves", offset1: 0, offset2: 0 },

    3: { name: "TVGdeeprough", offset1: 16, offset2: 10 },

    4: { name: "TVGconcrete", offset1: 48, offset2: 30 },
    13: { name: "TVGstone", offset1: 48, offset2: 30 },

    11: { name: "TVGsand", offset1: 64, offset2: 40 },

}

const VLAToSpeed = [
    0.95, 0.95, 0.98, 1.0, 1.0, 1.0, 0.98, 0.98, 0.95, 0.9,
    0.91, 0.91, 0.91, 0.92, 0.92, 0.93, 0.94, 0.94, 0.94, 0.94,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.95, 0.95, 0.95
];

const SpeedToSpeed = [
    0.98, 0.98, 0.98, 0.97, 0.97, 0.96, 0.96, 0.95, 0.95, 0.94,
    0.94, 0.94, 0.94, 0.94, 0.94, 0.94, 0.97, 0.94, 0.91, 0.88,
    0.87, 0.86, 0.86, 0.86, 0.86, 0.86, 0.86, 0.86, 0.86, 0.84,
    0.82, 0.8, 0.985, 0.985, 0.985, 0.985, 0.985, 0.985, 0.985, 0.985,
    0.985, 0.985, 0.985, 0.985, 0.985, 0.985, 0.985, 0.985, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    0.98, 0.96, 0.9, 0.6, 0.7, 0.72, 0.75, 0.78, 0.83, 0.88,
    0.9, 0.92, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93
];

const VLAToSpin = [
    0.9, 0.95, 0.95, 0.95, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.65, 0.68, 0.74, 0.74, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
];

const SpeedToSpin = [
    0.6, 0.63, 0.67, 0.7, 0.73, 0.77, 0.8, 0.85, 0.85, 0.85,
    0.85, 0.85, 0.85, 0.85, 0.85, 0.85, 0.6, 0.61, 0.65, 0.69,
    0.7, 0.74, 0.76, 0.76, 0.76, 0.76, 0.76, 0.76, 0.76, 0.76,
    0.76, 0.76, 0.95, 0.95, 0.95, 0.95, 0.95, 0.95, 0.95, 0.95,
    0.95, 0.95, 0.95, 0.95, 0.95, 0.95, 0.95, 0.95, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 0.5, 0.5, 0.6, 0.7, 0.8, 0.9,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
];

const SpeedToVLA = [
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
];

const VLAToVLA = [
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 0.98, 0.98, 0.98, 0.98, 0.98, 0.98, 0.98, 0.98, 0.98,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
];